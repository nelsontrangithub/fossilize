import { Project, Node, SyntaxKind, SourceFile } from "ts-morph";

export interface FossilizeOptions {
  /** Symbol names to keep fully expanded (do not fossilize their bodies). */
  keep?: string[];
  /** If true, strip leading comments / JSDoc. Default: false (kept — they're cheap and useful). */
  stripComments?: boolean;
  /** If true, preserve JSX return statements in components (only fossilize hooks/handlers). */
  keepJsx?: boolean;
}

export interface FossilStats {
  originalChars: number;
  fossilizedChars: number;
  originalTokens: number;
  fossilizedTokens: number;
  /** 0..1 — fraction of tokens removed. */
  savings: number;
}

export interface FossilResult {
  text: string;
  stats: FossilStats;
}

/** Rough token estimate (~4 chars/token is a decent code-shape approximation). */
export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

/** Fossilize a single source file given its on-disk path. */
export function fossilizeFile(
  filePath: string,
  options: FossilizeOptions = {},
): FossilResult {
  const project = new Project({
    skipAddingFilesFromTsConfig: true,
    skipFileDependencyResolution: true,
    compilerOptions: { allowJs: true, jsx: 4 /* Preserve */ },
  });
  const sourceFile = project.addSourceFileAtPath(filePath);
  return fossilizeSourceFile(sourceFile, options);
}

/** Fossilize from in-memory text (handy for tests). */
export function fossilizeText(
  text: string,
  fileName = "in.ts",
  options: FossilizeOptions = {},
): FossilResult {
  const project = new Project({
    useInMemoryFileSystem: true,
    compilerOptions: { allowJs: true, jsx: 4 /* Preserve */ },
  });
  const sourceFile = project.createSourceFile(fileName, text);
  return fossilizeSourceFile(sourceFile, options);
}

function fossilizeSourceFile(
  sourceFile: SourceFile,
  options: FossilizeOptions,
): FossilResult {
  const originalText = sourceFile.getFullText();
  const keep = new Set(options.keep ?? []);

  // Collect target bodies. We must NOT mutate while walking — ts-morph node
  // positions shift on each edit. Collect → sort bottom-up → replace.
  type Target = { body: Node; name: string; lineCount: number };
  const targets: Target[] = [];

  sourceFile.forEachDescendant((node) => {
    const t = bodyForNode(node);
    if (!t) return;
    if (keep.has(t.name)) return;

    const lineCount =
      t.body.getEndLineNumber() - t.body.getStartLineNumber();
    // Don't fossilize trivially short bodies — the marker would be longer than the code.
    if (lineCount <= 1) return;

    targets.push({ body: t.body, name: t.name, lineCount });
  });

  // Replace in reverse-position order so earlier edits don't invalidate later ones.
  targets.sort((a, b) => b.body.getStart() - a.body.getStart());

  for (const { body, lineCount } of targets) {
    body.replaceWithText(`{ /* fossil: ${lineCount}L */ }`);
  }

  if (options.stripComments) {
    // JSDoc strips cleanly via the structured API
    sourceFile.getClasses().forEach((c) => c.getJsDocs().forEach((j) => j.remove()));
    sourceFile.getFunctions().forEach((f) => f.getJsDocs().forEach((j) => j.remove()));
    sourceFile.getInterfaces().forEach((i) => i.getJsDocs().forEach((j) => j.remove()));
    sourceFile.getTypeAliases().forEach((t) => t.getJsDocs().forEach((j) => j.remove()));
    sourceFile.getEnums().forEach((e) => e.getJsDocs().forEach((j) => j.remove()));
    // Strip remaining // and /* */ comments via text pass on the final output
    const text = sourceFile.getFullText()
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/(^|[^:])\/\/[^\n]*/g, "$1")
      .replace(/\n\s*\n\s*\n/g, "\n\n");
    sourceFile.replaceWithText(text);
  }

  const fossilizedText = sourceFile.getFullText();

  return {
    text: fossilizedText,
    stats: {
      originalChars: originalText.length,
      fossilizedChars: fossilizedText.length,
      originalTokens: estimateTokens(originalText),
      fossilizedTokens: estimateTokens(fossilizedText),
      savings: 1 - fossilizedText.length / Math.max(originalText.length, 1),
    },
  };
}

/** Resolve "is this a function-like with a replaceable body?" → {body, name} */
function bodyForNode(node: Node): { body: Node; name: string } | null {
  if (Node.isFunctionDeclaration(node)) {
    const body = node.getBody();
    if (!body) return null;
    return { body, name: node.getName() ?? "<anonymous>" };
  }
  if (Node.isMethodDeclaration(node)) {
    const body = node.getBody();
    if (!body) return null;
    return { body, name: node.getName() };
  }
  if (Node.isConstructorDeclaration(node)) {
    const body = node.getBody();
    if (!body) return null;
    return { body, name: "constructor" };
  }
  if (Node.isGetAccessorDeclaration(node) || Node.isSetAccessorDeclaration(node)) {
    const body = node.getBody();
    if (!body) return null;
    return { body, name: node.getName() };
  }
  if (Node.isArrowFunction(node) || Node.isFunctionExpression(node)) {
    const body = node.getBody();
    if (!body || !Node.isBlock(body)) return null;
    const parent = node.getParent();
    let name = "<anonymous>";
    if (Node.isVariableDeclaration(parent)) name = parent.getName();
    else if (Node.isPropertyAssignment(parent)) name = parent.getName();
    return { body, name };
  }
  return null;
}

/** Find and return the original text of a named function/method, full body included. */
export function expandSymbol(filePath: string, symbol: string): string | null {
  const project = new Project({
    skipAddingFilesFromTsConfig: true,
    compilerOptions: { allowJs: true, jsx: 4 },
  });
  const sourceFile = project.addSourceFileAtPath(filePath);

  let result: string | null = null;

  sourceFile.forEachDescendant((node, traversal) => {
    if (result) {
      traversal.stop();
      return;
    }
    if (Node.isFunctionDeclaration(node) && node.getName() === symbol) {
      result = node.getText();
    } else if (Node.isMethodDeclaration(node) && node.getName() === symbol) {
      result = node.getText();
    } else if (Node.isVariableDeclaration(node) && node.getName() === symbol) {
      const init = node.getInitializer();
      if (init && (Node.isArrowFunction(init) || Node.isFunctionExpression(init))) {
        // Grab the whole statement so consumer sees `const foo = (...) => {...}`
        const stmt = node.getFirstAncestorByKind(SyntaxKind.VariableStatement);
        result = stmt ? stmt.getText() : node.getText();
      }
    }
  });

  return result;
}
