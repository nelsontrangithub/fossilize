#!/usr/bin/env node
import * as fs from "fs";
import * as path from "path";
import { glob } from "glob";
import {
  fossilizeFile,
  expandSymbol,
  estimateTokens,
  FossilResult,
} from "./fossilize";

const HELP = `
🦴 fossil — compress source files to AST skeletons

usage:
  fossil <path> [--out <dir>] [--strip-comments] [--keep <name,...>]
                              compress a file or directory; prints to stdout
                              unless --out is given
  fossil expand <file> <symbol>
                              print the original body of a named symbol
  fossil stats <path>         summarize token savings without printing source
  fossil help                 show this message

examples:
  fossil src/                 # fossilize whole src tree to stdout
  fossil src/auth.ts          # one file
  fossil src/ --out .fossil   # write skeleton copies into .fossil/
  fossil expand src/auth.ts verifyJwt
  fossil stats .
`;

interface Args {
  command: string;
  positional: string[];
  out?: string;
  stripComments: boolean;
  keep: string[];
}

function parseArgs(argv: string[]): Args {
  const a: Args = {
    command: argv[0] ?? "help",
    positional: [],
    stripComments: false,
    keep: [],
  };
  for (let i = 1; i < argv.length; i++) {
    const v = argv[i];
    if (v === "--out") a.out = argv[++i];
    else if (v === "--strip-comments") a.stripComments = true;
    else if (v === "--keep") a.keep = (argv[++i] ?? "").split(",").filter(Boolean);
    else a.positional.push(v);
  }
  return a;
}

async function collectFiles(target: string): Promise<string[]> {
  if (!fs.existsSync(target)) {
    throw new Error(`path not found: ${target}`);
  }
  const stat = fs.statSync(target);
  if (stat.isFile()) return [target];
  const pattern = path.posix.join(
    target.replace(/\\/g, "/"),
    "**/*.{ts,tsx,js,jsx,mts,cts}",
  );
  return glob(pattern, {
    ignore: ["**/node_modules/**", "**/dist/**", "**/build/**", "**/*.d.ts"],
    nodir: true,
  });
}

function formatPct(x: number): string {
  return `${(x * 100).toFixed(1)}%`;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (args.command === "help" || args.command === "--help" || args.command === "-h") {
    console.log(HELP);
    return;
  }

  if (args.command === "expand") {
    const [file, symbol] = args.positional;
    if (!file || !symbol) {
      console.error("usage: fossil expand <file> <symbol>");
      process.exit(2);
    }
    const out = expandSymbol(file, symbol);
    if (out == null) {
      console.error(`symbol not found: ${symbol} in ${file}`);
      process.exit(1);
    }
    console.log(out);
    return;
  }

  // For `stats` and the default compress action, the target path is either
  // command itself (default) or the first positional (stats).
  const isStats = args.command === "stats";
  const target = isStats ? args.positional[0] : args.command;
  if (!target) {
    console.log(HELP);
    process.exit(2);
  }

  const files = await collectFiles(target);
  if (files.length === 0) {
    console.error(`no source files found under ${target}`);
    process.exit(1);
  }

  let totalOrig = 0;
  let totalFoss = 0;
  const perFile: { file: string; result: FossilResult }[] = [];

  for (const file of files) {
    const result = fossilizeFile(file, {
      stripComments: args.stripComments,
      keep: args.keep,
    });
    totalOrig += result.stats.originalTokens;
    totalFoss += result.stats.fossilizedTokens;
    perFile.push({ file, result });
  }

  if (isStats) {
    // Show a per-file table + total
    const rows = perFile
      .map(({ file, result }) => {
        const o = result.stats.originalTokens;
        const f = result.stats.fossilizedTokens;
        const save = formatPct(result.stats.savings);
        return { file, o, f, save };
      })
      .sort((a, b) => b.o - a.o);

    const maxName = Math.max(...rows.map((r) => r.file.length), 4);
    console.log(`${"file".padEnd(maxName)}  ${"orig".padStart(7)}  ${"foss".padStart(7)}  saved`);
    console.log("-".repeat(maxName + 28));
    for (const r of rows) {
      console.log(
        `${r.file.padEnd(maxName)}  ${String(r.o).padStart(7)}  ${String(r.f).padStart(7)}  ${r.save}`,
      );
    }
    console.log("-".repeat(maxName + 28));
    const totalSave = 1 - totalFoss / Math.max(totalOrig, 1);
    console.log(
      `${"TOTAL".padEnd(maxName)}  ${String(totalOrig).padStart(7)}  ${String(totalFoss).padStart(7)}  ${formatPct(totalSave)}`,
    );
    return;
  }

  if (args.out) {
    for (const { file, result } of perFile) {
      const rel = path.relative(target, file);
      const outPath = path.join(args.out, rel);
      fs.mkdirSync(path.dirname(outPath), { recursive: true });
      fs.writeFileSync(outPath, result.text);
    }
    const totalSave = 1 - totalFoss / Math.max(totalOrig, 1);
    console.error(
      `🦴 ${files.length} files → ${args.out}: ${totalOrig} → ${totalFoss} tokens (${formatPct(totalSave)} saved)`,
    );
  } else {
    for (const { file, result } of perFile) {
      console.log(`// ===== ${file} =====`);
      console.log(result.text);
      console.log();
    }
    const totalSave = 1 - totalFoss / Math.max(totalOrig, 1);
    console.error(
      `🦴 ${files.length} files: ${totalOrig} → ${totalFoss} tokens (${formatPct(totalSave)} saved)`,
    );
  }
}

main().catch((e) => {
  console.error(`fossil: ${e instanceof Error ? e.message : String(e)}`);
  process.exit(1);
});
