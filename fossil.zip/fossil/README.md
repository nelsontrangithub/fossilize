# 🦴 fossil

**make your repo extinct-skeleton small**

[Install](#install) • [Before / After](#before--after) • [Why](#why) • [How](#how-it-works) • [Roadmap](#roadmap)

---

A CLI + Claude Code skill that compresses TypeScript / JavaScript source files into their **AST skeleton** before they ever hit your agent's context window. Cuts 70–90% of input tokens on real codebases. Bodies are retrievable on demand via `fossil expand`.

Sibling to [caveman](https://github.com/JuliusBrussee/caveman) — caveman makes Claude *talk* with fewer tokens, fossil makes Claude *read* with fewer tokens. Together, the full Stone Age stack.

## Before / After

A real Express auth middleware file:

| Original | Fossilized |
|---|---|
| 748 tokens | **238 tokens (68% saved)** |
| 102 lines of code | 30 lines, every signature intact |

On the fossil project's own source:

```
file                 orig     foss  saved
--------------------------------------------
src/fossilize.ts     1628      438  73.1%
src/cli.ts           1371      344  74.9%
--------------------------------------------
TOTAL                2999      782  73.9%
```

On larger real-world repos: typically 80–90% reduction. A 200k-token repo becomes 25k tokens — fits in context with room to actually *work*.

## Install

```bash
npm install -g fossil-cli
```

As a Claude Code skill:

```bash
claude install-skill JuliusBrussee/fossil
```

## Usage

```bash
fossil src/                       # fossilize whole src/ tree to stdout
fossil src/auth.ts                # single file
fossil src/ --out .fossil         # write skeleton copies into .fossil/
fossil stats .                    # see token savings per file
fossil expand src/auth.ts foo     # retrieve original body of one symbol
fossil src/ --keep foo,bar        # fossilize, but keep foo and bar full
fossil src/ --strip-comments      # also drop comments and JSDoc
```

## Why

AI coding tools burn input tokens at terrifying rates. The math:

- A 500-line TypeScript file ≈ 4,000 tokens
- A medium repo (40 files like that) ≈ 160,000 tokens
- Most of that is **function bodies** Claude doesn't need to see most of the time — it needs signatures, types, and shapes to write correct calling code

caveman tackled the output side (verbose Claude prose). fossil tackles the input side (verbose source files). Same Stone Age vibe, different optimization target.

## How It Works

fossil parses with [ts-morph](https://ts-morph.com) (a TypeScript Compiler API wrapper). It walks the AST and replaces function/method/constructor/accessor/arrow bodies with a marker:

```ts
// before
export function verifyJwt(token: string, secret: string): JwtPayload | null {
  try {
    return jwt.verify(token, secret) as JwtPayload;
  } catch {
    return null;
  }
}

// after
export function verifyJwt(token: string, secret: string): JwtPayload | null { /* fossil: 6L */ }
```

Everything else stays exactly as-is:
- Imports, exports
- Interfaces, types, enums
- Class declarations and fields
- Function/method **signatures** with full parameter and return types
- JSDoc above declarations

Trivial single-line bodies aren't touched (the marker would be longer than the code).

When the agent actually needs a body, `fossil expand <file> <symbol>` pulls just that function, full source. Just-in-time loading instead of upfront everything-into-context.

## Token Math

| Approach | Tokens for a 40-file repo |
|---|---|
| Read every file raw | ~160k |
| Read fossilized | **~25k** |
| Read fossilized + expand 3 functions you actually need | **~28k** |

83% reduction with no loss of the structural information Claude needs to reason about the architecture.

## Roadmap

- [ ] **JSX-aware mode** — keep `return (<...>)` JSX trees in React components, only fossilize hooks and handlers
- [ ] **C# / Roslyn backend** — same idea, ASP.NET / .NET solutions
- [ ] **Python / tree-sitter backend** — broader language support
- [ ] **`fossil watch`** — live mirror of `src/` → `.fossil/` for use with any agent
- [ ] **MCP server** — expose fossilize and expand as MCP tools so any client (not just Claude Code) can use them
- [ ] **Auto-summary mode** — replace bodies with a one-line natural-language description instead of just a line count (opt-in, calls LLM)

## License

MIT.

## Star this repo

If fossil saves you mass token, mass money — leave mass star ⭐
